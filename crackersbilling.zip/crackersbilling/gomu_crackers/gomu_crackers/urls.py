from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('billing/', include('billing_app.urls')),
    path('', RedirectView.as_view(url='/billing/', permanent=False)),
]